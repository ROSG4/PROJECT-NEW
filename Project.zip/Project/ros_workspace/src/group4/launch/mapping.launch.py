import os


from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode




def generate_launch_description():
  use_sim_time = LaunchConfiguration('use_sim_time')


  robot_location = os.path.join(get_package_share_directory('group4') , 'robots', 'abc.urdf')
  localisation_params = os.path.join(get_package_share_directory("group4"), 'config', 'localj.yaml'),


  with open(robot_location, 'r') as infp:
      robot_desc = infp.read()
      
  rviz_launch_arg = DeclareLaunchArgument(
      'rviz', default_value='true',
      description='Open RViz.'
  )

  lidar_sensor = Node(
      package = 'sick_scan_xd',
      executable = 'sick_generic_caller',
      output = 'screen',
      name ='abc',
      arguments=['hostname:=192.168.0.1','scanner_type:=sick_tim_7xx',],
      remappings=[('/sick_tim_7xx/scan', '/lidar')]
  )


  joint_state_pub = Node(
      package='joint_state_publisher',
      executable='joint_state_publisher',
      name = 'joint_state_publisher'
  )
  
  rviz = Node(
      package='rviz2',
      executable='rviz2',
      # arguments=['-d', os.path.join(pkg_ros_gz_sim_demos, 'rviz', 'vehicle.rviz')],
      condition=IfCondition(LaunchConfiguration('rviz')),
      parameters=[
          {'use_sim_time': False},
      ]
  )


  robot_state_publisher = Node(
      package='robot_state_publisher',
      executable='robot_state_publisher',
      name='robot_state_publisher',
      output='both',
      parameters=[
          {'use_sim_time': False},
          {'robot_description': robot_desc},
      ]
  )



  pioneer_base_fp_link_tf = Node(
      package = 'tf2_ros',
      executable = 'static_transform_publisher',
      name = 'base_fp_linkTF',
      output = 'log',
      arguments = ['0.0', '0.0', '0.0', '0.0', '0.0', '0.0','base_footprint', 'pioneer3at_body/base_footprint'], #'map', 'scan'


  )


  localization = Node(
       package = 'robot_localization',
       executable = 'ekf_node',
       name='ekf_filter_node',
       parameters = [localisation_params],
       remappings = [('/odometry/filtered', '/odom')]


  )
  
  imu_update = Node(
        package ='group4',
        executable ='imuCorrection',
        name='imu_corrector',
        output='screen',
   )



  
  slam_toolbox = Node( 
       package='slam_toolbox', 
       executable='async_slam_toolbox_node', 
       name= 'slam_toolbox',
       parameters=[os.path.join(get_package_share_directory('group4') + '/config'+ '/mapping.yaml')], 
       output='screen',
       
   )
  
  phidgets = ComposableNodeContainer(
       name = 'imu_container',
       namespace='',
       package='rclcpp_components',
       executable='component_container',
       composable_node_descriptions=[
           ComposableNode(
               package = 'phidgets_spatial',
               plugin='phidgets::SpatialRosI',
               name='phidgets_spatial',
               parameters = [
                   os.path.join(get_package_share_directory("group4") + '/config'+ '/phidget_spatial.yaml')
               ],
               
               
           ),
       ],
       output = 'both',
  )


  camera = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory('depthai_ros_driver'),'launch/camera.launch.py')),
        launch_arguments={'usb_device_path': '/dev/bus/usb/003/009'}.items(),

    )

  use_sim_time = LaunchConfiguration('use_sim_time')


  joy_params = os.path.join(get_package_share_directory('group4') + '/config' +'/joystick.yaml')
  params = os.path.join(get_package_share_directory('group4') + '/config' +'/joy.yaml')




  joy_node = Node(
           package='joy',
           executable='joy_node',
           name='joy_node',
           parameters=[{'dev': 'dev/input/js0'}],
        )


  teleop_twist_joy_node = Node(
           package='teleop_twist_joy',
           executable='teleop_node',
           name='teleop_twist_joy_node',
           parameters=[joy_params],
           remappings = [('cmd_vel', '/cmd_vel/manual')]

           
        )
   
  ariaNode = Node(
       package = 'ariaNode',
       executable='ariaNode',
       name='aria',
       #parameters=[{'rp':'/dev/ttyUSB0'}],
       arguments=['-rp', '/dev/ttyUSB0'],
   )

  deadman = Node(
        package ='group4',
        executable ='deadm',
        name='deadman',
        output='screen',
   )
  remap = Node(
        package ='group4',
        executable ='cmd_vel_remap',
        name='cmd_vel_remap',
        output='screen',
   )

  marker_publisher = Node(
            package='my_markers_pkg',
            executable='marker_publisher',
            name='marker_publisher',
            output='screen'
   )
  
  integrate = Node(
        package ='group4',
        executable ='integrate_velocity',
        name='odom_janky',
        output='screen',
   )



	# Nav2 bringup for navigation
  navigation = IncludeLaunchDescription(
		PythonLaunchDescriptionSource(os.path.join(get_package_share_directory('nav2_bringup'), 'launch', 'navigation_launch.py')),
		launch_arguments={
			'map_subscribe_transient_local': 'true',
			'use_sim_time': 'false',
			'params_file': os.path.join(get_package_share_directory('group4') , 'config' , 'navigation.yaml'),
			'/cmd_vel': '/cmd_vel/auto'
		}.items(),
	)


  return LaunchDescription([
	#   rviz_launch_arg,
	#   rviz,
	#   lidar_sensor,
	#   robot_state_publisher,
	#   pioneer_base_fp_link_tf,
	#   joint_state_pub,
	#   #phidgets,
	  #camera,
	  #localization,
	  slam_toolbox,
	#   ariaNode,
	#   teleop_twist_joy_node,
	#   joy_node,
	#   deadman,
	#   #imu_update,
	  #remap,
	  navigation,
      integrate,

	  
  ])
