import os


from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode




def generate_launch_description():



  lidar_sensor = Node(
      package = 'sick_scan_xd',
      executable = 'sick_generic_caller',
      output = 'screen',
      name ='abc',
      arguments=['hostname:=192.168.0.1','scanner_type:=sick_tim_7xx',],
      remappings=[('/sick_tim_7xx/scan', '/lidar')]
  )


  
  imu_update = Node(
        package ='group4',
        executable ='imuCorrection',
        name='imu_corrector',
        output='screen',
   )


  
  phidgets = ComposableNodeContainer(
       name = 'imu_container',
       namespace='',
       package='rclcpp_components',
       executable='component_container',
       composable_node_descriptions=[
           ComposableNode(
               package = 'phidgets_spatial',
               plugin='phidgets::SpatialRosI',
               name='phidgets_spatial',
               parameters = [
                   os.path.join(get_package_share_directory("group4") + '/config'+ '/phidget_spatial.yaml')
               ],
               
               
           ),
       ],
       output = 'both',
  )











  return LaunchDescription([
    lidar_sensor,
    phidgets,
  ])
