import os
import launch

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode




def generate_launch_description():
  use_sim_time = LaunchConfiguration('use_sim_time')


  robot_location = os.path.join(get_package_share_directory('group4') + '/robots/abc.urdf')
  


  with open(robot_location, 'r') as infp:
      robot_desc = infp.read()
      
  rviz_launch_arg = DeclareLaunchArgument(
      'rviz', default_value='true',
      description='Open RViz.'
  )



  joint_state_pub = Node(
      package='joint_state_publisher',
      executable='joint_state_publisher',
      name = 'joint_state_publisher'
  )
  
  rviz = Node(
      package='rviz2',
      executable='rviz2',
      # arguments=['-d', os.path.join(pkg_ros_gz_sim_demos, 'rviz', 'vehicle.rviz')],
      condition=IfCondition(LaunchConfiguration('rviz')),
      parameters=[
          {'use_sim_time': False},
      ]
  )


  robot_state_publisher = Node(
      package='robot_state_publisher',
      executable='robot_state_publisher',
      name='robot_state_publisher',
      output='both',
      parameters=[
          {'use_sim_time': False},
          {'robot_description': robot_desc},
      ]
  )


  camera = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory('depthai_ros_driver'),'launch/camera.launch.py')),
        launch_arguments={'usb_device_path': '/dev/bus/usb/003/009'}.items(),

    )

  pioneer_base_fp_link_tf = Node(
      package = 'tf2_ros',
      executable = 'static_transform_publisher',
      name = 'base_fp_linkTF',
      output = 'log',
      arguments = ['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'pioneer3at_body/base_footprint', 'base_footprint'], #'map', 'scan'


  )

  colour = Node(
        package ='group4',
        executable ='colourSub',
        name = 'colour',
        output = 'screen',
   )
  
  digit = Node(
        package ='group4',
        executable ='digitNode',
        name = 'digit',
        output = 'screen',
   )
  
  record = executeProcess(
            cmd=['ros2', 'bag', 'record', '-o', 'colourBAG', '/colour_code'],
            output='screen'
   )

  

  return LaunchDescription([
      rviz_launch_arg,
      rviz,
      robot_state_publisher,
      pioneer_base_fp_link_tf,
      joint_state_pub,
      camera,
      colour,
      digit,
      record,
  ])
