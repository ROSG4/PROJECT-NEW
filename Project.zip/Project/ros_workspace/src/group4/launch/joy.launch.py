from launch import LaunchDescription
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument


import os
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
   use_sim_time = LaunchConfiguration('use_sim_time')


   joy_params = os.path.join(get_package_share_directory('group4') + '/config' +'/joystick.yaml')
   params = os.path.join(get_package_share_directory('group4') + '/config' +'/joy.yaml')
   



   joy_node = Node(
           package='joy',
           executable='joy_node',
           name='joy_node',
           parameters=[{'dev': 'dev/input/js0'}],
        )


   teleop_twist_joy_node = Node(
           package='teleop_twist_joy',
           executable='teleop_node',
           name='teleop_twist_joy_node',
           parameters=[joy_params],
           remappings=[('cmd_vel', 'cmd_vel/manual')],
           
        )
   
   ariaNode = Node(
       package = 'ariaNode',
       executable='ariaNode',
       name='arialikesmen',
       #parameters=[{'rp':'/dev/ttyUSB0'}],
       arguments=['-rp', '/dev/ttyUSB0'],
       
   )

   deadman = Node(
        package ='group4',
        executable ='deadm',
        name='deadman',
        output='screen',
   )
  
   auto = Node(
        package ='group4',
        executable ='auto_drive',
        name='auto_drive',
        output='screen',
   )

   return_home = Node(
        package ='group4',
        executable ='return_home',
        name='return_home',
        output='screen',
  )




   return LaunchDescription([
       joy_node,
       teleop_twist_joy_node,
       ariaNode,
       deadman,
       auto,
       return_home,
            
   ])
