import os


from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode




def generate_launch_description():
  use_sim_time = LaunchConfiguration('use_sim_time')


  slam_toolbox = Node( 
       package='slam_toolbox', 
       executable='async_slam_toolbox_node', 
       name= 'slam_toolbox',
       parameters=[os.path.join(get_package_share_directory('group4') + '/config'+ '/mapping.yaml')], 
       output='screen',
       
   )
  

	# Nav2 bringup for navigation
  navigation = IncludeLaunchDescription(
		PythonLaunchDescriptionSource(os.path.join(get_package_share_directory('nav2_bringup'), 'launch', 'navigation_launch.py')),
		launch_arguments={
			'map_subscribe_transient_local': 'true',
			'use_sim_time': 'false',
			'params_file': os.path.join(get_package_share_directory('group4') , 'config' , 'navigation.yaml'),
			'/cmd_vel': '/cmd_vel/auto'
		}.items(),
	)

  integrate = Node(
        package ='group4',
        executable ='integrate_velocity',
        name='odom_janky',
        output='screen',
   )


  return LaunchDescription([
	  slam_toolbox,
	  navigation,
      integrate,
  ])
