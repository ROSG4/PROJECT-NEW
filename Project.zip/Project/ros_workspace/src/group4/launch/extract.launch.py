import os
import launch

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode




def generate_launch_description():
  use_sim_time = LaunchConfiguration('use_sim_time')


  robot_location = os.path.join(get_package_share_directory('group4') + '/robots/abc.urdf')
  


  with open(robot_location, 'r') as infp:
      robot_desc = infp.read()
      
  rviz_launch_arg = DeclareLaunchArgument(
      'rviz', default_value='true',
      description='Open RViz.'
  )



  joint_state_pub = Node(
      package='joint_state_publisher',
      executable='joint_state_publisher',
      name = 'joint_state_publisher'
  )
  
  rviz = Node(
      package='rviz2',
      executable='rviz2',
      # arguments=['-d', os.path.join(pkg_ros_gz_sim_demos, 'rviz', 'vehicle.rviz')],
      condition=IfCondition(LaunchConfiguration('rviz')),
      parameters=[
          {'use_sim_time': False},
      ]
  )


  robot_state_publisher = Node(
      package='robot_state_publisher',
      executable='robot_state_publisher',
      name='robot_state_publisher',
      output='both',
      parameters=[
          {'use_sim_time': False},
          {'robot_description': robot_desc},
      ]
  )


  

  

  return LaunchDescription([
      ExecuteProcess(
        cmd=['ros2', 'bag', 'play', 'colourBAG', '--all'],
        output='screen'
      )
      ])
