from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'group4'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share/' + package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share/' + package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share/' + package_name, 'robots'), glob('robots/*.urdf')),


    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='laptop-group4',
    maintainer_email='laptop-group4@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            
            'deadm = group4.deadmanNode:main',
            'colourSub = group4.colour_sub:main',
            'digitNode = group4.digit_Node:main',
            'imuCorrection = group4.imu_correction:main',
            'cmd_vel_remap = group4.cmd_vel_remap:main',
            'marker_publisher = group4.marker_publisher:main',
            'video_container = group4.video_converter:main',
            'integrate_velocity = group4.vel_integrate:main',
            'auto_drive = group4.auto_drive:main',
            'return_home = group4.return_to_home:main',
        ],
    },
)
