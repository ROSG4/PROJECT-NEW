#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import math
from transforms3d.euler import euler2quat, quat2euler
import tf2_ros
from geometry_msgs.msg import TransformStamped

class CmdVelLocalizationNode(Node):
    def __init__(self):
        super().__init__('cmd_vel_localization_node')
        self.subscription = self.create_subscription(
            Twist,
            'aria_vel',
            self.cmd_vel_callback,
            10)
        self.publisher = self.create_publisher(Odometry, 'odom', 10)
        
        # Initial position and orientation
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        
        # Initial velocities
        self.last_vx = 0.0
        self.last_vy = 0.0
        self.last_vth = 0.0
        
        # Initial time
        self.last_time = self.get_clock().now()
        
        self.timer = self.create_timer(0.1, self.publish_odometry)

        # Initialize tf2 broadcaster
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)

    def cmd_vel_callback(self, msg):
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9  # convert to seconds

        # Linear and angular velocities
        self.last_vx = msg.linear.x
        self.last_vy = msg.linear.y  # This is usually zero for differential drive robots
        self.last_vth = msg.angular.z

        # Update the position
        delta_x = (self.last_vx * math.cos(self.theta) - self.last_vy * math.sin(self.theta)) * dt
        delta_y = (self.last_vx * math.sin(self.theta) + self.last_vy * math.cos(self.theta)) * dt
        delta_th = self.last_vth * dt

        self.x += delta_x
        self.y += delta_y
        self.theta += delta_th

        self.last_time = current_time

    def publish_odometry(self):
        # Create an Odometry message
        odom = Odometry()
        
        # Populate the position
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0
        odom_quat = euler2quat(0, 0, self.theta)
        odom.pose.pose.orientation.x = odom_quat[1]
        odom.pose.pose.orientation.y = odom_quat[2]
        odom.pose.pose.orientation.z = odom_quat[3]
        odom.pose.pose.orientation.w = odom_quat[0]

        # Populate the velocity
        odom.twist.twist.linear.x = self.last_vx
        odom.twist.twist.linear.y = self.last_vy
        odom.twist.twist.angular.z = self.last_vth

        # Publish the odometry message
        self.publisher.publish(odom)

        # Publish the transform
        transform = TransformStamped()
        transform.header.stamp = self.get_clock().now().to_msg()
        transform.header.frame_id = "odom"
        transform.child_frame_id = "base_link"
        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.translation.z = 0.0
        transform.transform.rotation.x = odom_quat[1]
        transform.transform.rotation.y = odom_quat[2]
        transform.transform.rotation.z = odom_quat[3]
        transform.transform.rotation.w = odom_quat[0]

        self.tf_broadcaster.sendTransform(transform)

def main(args=None):
    rclpy.init(args=args)
    node = CmdVelLocalizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
