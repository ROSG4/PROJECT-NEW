#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool

class JoyToCmdVel(Node):
    def __init__(self):
        super().__init__('joy_to_cmd_vel')
        self.subscription = self.create_subscription(Joy, '/joy', self.joy_callback, 10)
        self.publisher = self.create_publisher(Twist, '/aria_vel', 10)
        self.bool_publisher = self.create_publisher(Bool, '/enable_autonomous', 10)
   
        self.l2_axis = 4
        self.o_button = 1
        self.x_button = 0

        self.manual_twist = Twist()
        self.auto_twist = Twist()
    
        self.manual_mode = False
        self.auto_mode = False

        self.manual_subscriber = self.create_subscription(Twist, '/cmd_vel/manual', self.manual_callback, 10)
        self.auto_subscriber = self.create_subscription(Twist, '/cmd_vel', self.auto_callback, 10)
        self.get_logger().info(' node has been started.')

    def joy_callback(self, joy_msg):
        twist = Twist()
        auto = Bool()

        if joy_msg.buttons[self.o_button] == 1:
            self.manual_mode = True
            self.auto_mode = False
            auto.data = False
            if self.manual_mode:
                self.get_logger().info('Manual mode enabled.')
        elif joy_msg.buttons[self.x_button] == 1:
            self.manual_mode = False
            self.auto_mode = True
            auto.data = True
            if self.auto_mode:
                self.get_logger().info('Auto mode enabled.')

        if joy_msg.axes[self.l2_axis] > -0.5:
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.publisher.publish(twist)
            self.get_logger().info(f'DEADMAN NOT PRESSED! HOLD L2!!')
        else:
            if self.manual_mode:
                self.publisher.publish(self.manual_twist)
                msg = Bool()
                msg.data = False
                self.bool_publisher.publish(msg)
            elif self.auto_mode:
                self.publisher.publish(self.auto_twist)
                msg = Bool()
                msg.data = True
                self.bool_publisher.publish(msg)
                
   

    def manual_callback(self, msg):
        self.manual_twist = msg

    def auto_callback(self, msg):
        self.auto_twist = msg

def main(args=None):
    rclpy.init(args=args)
    node = JoyToCmdVel()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
