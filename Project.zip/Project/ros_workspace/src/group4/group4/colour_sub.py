import cv2
import rclpy
from rclpy.node import Node
from rclpy.timer import Timer
from cv_bridge import CvBridge
from sensor_msgs.msg import Image as ROSImage
from visualization_msgs.msg import Marker
from tf2_ros import TransformListener, Buffer
import numpy as np
import time

class ColorObjectDetector(Node):

    def __init__(self):
        super().__init__('color_object_detector')
        self.subscription = self.create_subscription(
            ROSImage,
            '/oak/rgb/image_raw',  # Topic name
            self.listener_callback,
            10)
        self.publisher = self.create_publisher(ROSImage, 'colourDetection', 10)
        self.detection_publisher = self.create_publisher(ROSImage, 'colour_out', 10)
        self.marker_publisher = self.create_publisher(Marker, 'visualization_marker', 10)
        self.cv_bridge = CvBridge()
        self.cone_id = 0

        # Parameters for HSV ranges and area threshold
        self.red_lower = np.array([0, 150, 150], dtype=np.uint8)
        self.red_upper = np.array([10, 255, 255], dtype=np.uint8)
        self.yellow_lower = np.array([25, 150, 150], dtype=np.uint8)
        self.yellow_upper = np.array([35, 255, 255], dtype=np.uint8)
        self.area_threshold = 2000

        # Detection state
        self.detected_red = False
        self.detected_yellow = False
        self.detection_time = None

        # Timer for resetting detection state
        self.reset_timer = self.create_timer(5.0, self.reset_detection)

        # Timer for publishing detection after delay
        self.detection_delay_timer = None

        # TF buffer and listener
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

    def set_color_ranges(self, red_lower, red_upper, yellow_lower, yellow_upper, area_threshold):
        self.red_lower = np.array(red_lower, dtype=np.uint8)
        self.red_upper = np.array(red_upper, dtype=np.uint8)
        self.yellow_lower = np.array(yellow_lower, dtype=np.uint8)
        self.yellow_upper = np.array(yellow_upper, dtype=np.uint8)
        self.area_threshold = area_threshold

    def reset_detection(self):
        self.detected_red = False
        self.detected_yellow = False
        self.detection_time = None
        if self.detection_delay_timer:
            self.detection_delay_timer.cancel()
            self.detection_delay_timer = None

    def listener_callback(self, msg):
        try:
            if msg.encoding == "16UC1":
                # Convert 16UC1 depth image to 8-bit grayscale, then to BGR
                depth_image = self.cv_bridge.imgmsg_to_cv2(msg, desired_encoding="passthrough")
                frame = cv2.normalize(depth_image, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
            elif msg.encoding == "8UC1":
                # Convert 8-bit grayscale image to BGR
                grayscale_image = self.cv_bridge.imgmsg_to_cv2(msg, desired_encoding="mono8")
                frame = cv2.cvtColor(grayscale_image, cv2.COLOR_GRAY2BGR)
            else:
                # Default to BGR8
                frame = self.cv_bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except Exception as e:
            self.get_logger().info(f"Error converting ROS Image to OpenCV: {e}")
            return

        hsv_image = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Combine masks for red and yellow
        red_mask = cv2.inRange(hsv_image, self.red_lower, self.red_upper)
        yellow_mask = cv2.inRange(hsv_image, self.yellow_lower, self.yellow_upper)
        combined_mask = cv2.bitwise_or(red_mask, yellow_mask)

        # Find contours
        contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detected_red = False
        detected_yellow = False

        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)

            # Check if the detected object is large enough
            if cv2.contourArea(contour) > self.area_threshold:
                # Determine if the object is red or yellow
                if cv2.countNonZero(red_mask[y:y + h, x:x + w]) > 0:
                    detected_red = True
                if cv2.countNonZero(yellow_mask[y:y + h, x:x + w]) > 0:
                    detected_yellow = True

                # Draw bounding box around the detected object
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # If a new detection is made, start a timer to publish the detection after 0.5 seconds
        if detected_red and not self.detected_red:
            self.get_logger().info("Detected red object")
            self.detected_red = True
            self.detection_time = time.time()
            self.detection_delay_timer = self.create_timer(0.5, lambda: self.publish_detection(frame, "red"))
            self.publish_marker("red")

        if detected_yellow and not self.detected_yellow:
            self.get_logger().info("Detected yellow object")
            self.detected_yellow = True
            self.detection_time = time.time()
            self.detection_delay_timer = self.create_timer(0.5, lambda: self.publish_detection(frame, "yellow"))
            self.publish_marker("yellow")

        # Publish the frame with bounding boxes to 'colourDetection' topic
        try:
            self.publisher.publish(self.cv_bridge.cv2_to_imgmsg(frame, encoding="bgr8"))
        except Exception as e:
            self.get_logger().info(f"Error converting OpenCV Image to ROS Image: {e}")

    def publish_detection(self, frame, color):
        # Create a new ROSImage message with the detection information
        detection_msg = self.cv_bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        detection_msg.header.stamp = self.get_clock().now().to_msg()
        detection_msg.header.frame_id = color
        self.detection_publisher.publish(detection_msg)

        # Cancel the detection delay timer
        if self.detection_delay_timer is not None:
            self.detection_delay_timer.cancel()
            self.detection_delay_timer = None

        # Reset detection state after publishing the image
        self.detection_time = time.time()

    def publish_marker(self, color):
        try:
            # Get the transformation from 'map' to 'cloud'
            transform = self.tf_buffer.lookup_transform('map', 'cloud', rclpy.time.Time())

            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.id = self.cone_id
            self.cone_id += 1

            marker.type = Marker.CUBE
            marker.action = Marker.ADD
            marker.pose.position.x = transform.transform.translation.x
            marker.pose.position.y = transform.transform.translation.y
            marker.pose.position.z = 0.0
            marker.pose.orientation = transform.transform.rotation
            marker.scale.x = 0.3
            marker.scale.y = 0.3
            marker.scale.z = 2.0
            marker.color.a = 1.0  # Don't forget to set the alpha!
            if color == "red":
                marker.color.r = 1.0
                marker.color.g = 0.0
                marker.color.b = 0.0
            elif color == "yellow":
                marker.color.r = 1.0
                marker.color.g = 1.0
                marker.color.b = 0.0

            self.marker_publisher.publish(marker)
            self.get_logger().info(f'Publishing {color} marker at ({marker.pose.position.x}, {marker.pose.position.y})')

        except Exception as e:
            self.get_logger().info(f"Error getting transform from 'map' to 'cloud': {e}")

def main(args=None):
    rclpy.init(args=args)
    color_object_detector = ColorObjectDetector()

    # Adjust color ranges and area threshold as needed
    color_object_detector.set_color_ranges(
        red_lower=[0, 150, 150],
        red_upper=[10, 255, 255],
        yellow_lower=[25, 150, 150],
        yellow_upper=[35, 255, 255],
        area_threshold=3500
    )

    rclpy.spin(color_object_detector)
    color_object_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
