import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Int32
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from nav_msgs.msg import OccupancyGrid
import random
import numpy as np
import tf2_ros

class AutonomousNavigator(Node):
    def __init__(self):
        super().__init__('autonomous_navigator')
        self.subscription = self.create_subscription(
            Bool,
            'enable_autonomous',
            self.listener_callback,
            10)
        self.action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.costmap_sub = self.create_subscription(
            OccupancyGrid,
            '/local_costmap/costmap',
            self.costmap_callback,
            10)
        self.waypoint_count_pub = self.create_publisher(Int32, 'waypoint_count', 10)  # Publisher for waypoint count
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.enabled = False
        self.costmap = None
        self.navigating = False
        self.waypoint_count = 0
        self.timer = self.create_timer(1.0, self.timer_callback)  # Timer to periodically check and send goals

    def listener_callback(self, msg):
        self.enabled = msg.data
        if self.enabled and not self.navigating:
            self.navigate_to_waypoints()

    def costmap_callback(self, msg):
        self.costmap = msg

    def timer_callback(self):
        if self.enabled and not self.navigating:
            self.navigate_to_waypoints()

    def navigate_to_waypoints(self):
        if self.enabled and self.costmap is not None:
            self.navigating = True
            goal = self.create_random_goal()
            if goal:
                while not self.action_client.wait_for_server(timeout_sec=1.0):
                    pass  # Wait for the action server
                self.send_goal(goal)
            else:
                self.navigating = False

    def create_random_goal(self):
        try:
            map_transform = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
            return None

        robot_x = map_transform.transform.translation.x
        robot_y = map_transform.transform.translation.y

        boundary_x_min = -6.5
        boundary_x_max = 6.5
        boundary_y_min = -6.5
        boundary_y_max = 6.5

        local_area_size = 2.75

        local_costmap_data = np.array(self.costmap.data).reshape(self.costmap.info.height, self.costmap.info.width)
        resolution = self.costmap.info.resolution
        origin_x = self.costmap.info.origin.position.x
        origin_y = self.costmap.info.origin.position.y

        for _ in range(100):  # Try up to 100 random points
            rand_x = random.uniform(-local_area_size / 2, local_area_size / 2)
            rand_y = random.uniform(-local_area_size / 2, local_area_size / 2)

            global_x = robot_x + rand_x
            global_y = robot_y + rand_y

            cell_x = int((global_x - origin_x) / resolution)
            cell_y = int((global_y - origin_y) / resolution)

            if (boundary_x_min <= global_x <= boundary_x_max and
                boundary_y_min <= global_y <= boundary_y_max and
                0 <= cell_x < local_costmap_data.shape[1] and
                0 <= cell_y < local_costmap_data.shape[0] and
                local_costmap_data[cell_y, cell_x] == 0):  # Unoccupied cell
                goal = PoseStamped()
                goal.header.frame_id = 'map'
                goal.header.stamp = self.get_clock().now().to_msg()
                goal.pose.position.x = global_x
                goal.pose.position.y = global_y
                goal.pose.orientation.w = 1.0  # Facing forward
                return goal
        return None  # Could not find a valid goal

    def send_goal(self, goal):
        nav_goal = NavigateToPose.Goal()
        nav_goal.pose = goal
        future = self.action_client.send_goal_async(nav_goal)
        future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.navigating = False
            return
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result()
        if result and result.result:
            self.waypoint_count += 1
            msg = Int32()
            msg.data = self.waypoint_count
            self.waypoint_count_pub.publish(msg)  # Publish the waypoint count
        self.navigating = False  # Allow navigation to the next waypoint

def main(args=None):
    rclpy.init(args=args)
    navigator = AutonomousNavigator()
    rclpy.spin(navigator)
    navigator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
