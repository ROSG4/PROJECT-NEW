#'/oak/rgb/image_raw'
import cv2
import rclpy
from rclpy.node import Node
from cv_bridge import CvBridge
from sensor_msgs.msg import Image as ROSImage
import numpy as np

class ColorObjectDetector(Node):

    def __init__(self):
        super().__init__('color_object_detector')
        self.subscription = self.create_subscription(
            ROSImage,
            '/oak/rgb/image_raw',  # Update this topic name with your publisher's topic
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.cv_bridge = CvBridge()

    def get_limits(self):
        # Define narrow ranges for red and yellow hues
        red_lower = np.array([0, 150, 150], dtype=np.uint8)
        red_upper = np.array([10, 255, 255], dtype=np.uint8)

        yellow_lower = np.array([25, 150, 150], dtype=np.uint8)
        yellow_upper = np.array([35, 255, 255], dtype=np.uint8)

        return (red_lower, red_upper), (yellow_lower, yellow_upper)

    def listener_callback(self, msg):
        try:
            self.get_logger().info("Received ROS Image")
            self.get_logger().info(f"ROS Image encoding: {msg.encoding}")
            frame = self.cv_bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except Exception as e:
            self.get_logger().info(f"Error converting ROS Image to OpenCV: {e}")
            return

        self.get_logger().info("Receiving Video Frame")
        hsv_image = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        red_range, yellow_range = self.get_limits()

        # Combine masks for red and yellow
        red_mask = cv2.inRange(hsv_image, red_range[0], red_range[1])
        yellow_mask = cv2.inRange(hsv_image, yellow_range[0], yellow_range[1])
        combined_mask = cv2.bitwise_or(red_mask, yellow_mask)

        # Find contours
        contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detected_red = False
        detected_yellow = False

        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)

            # Check if the detected object is large enough
            if cv2.contourArea(contour) > 2000:  # Adjust the threshold as needed
                # Determine if the object is red or yellow
                if cv2.countNonZero(red_mask[y:y+h, x:x+w]) > 0:
                    detected_red = True
                if cv2.countNonZero(yellow_mask[y:y+h, x:x+w]) > 0:
                    detected_yellow = True

                # Draw bounding box around the detected object
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        if detected_red:
            self.get_logger().info("Detected red object")
        if detected_yellow:
            self.get_logger().info("Detected yellow object")

        cv2.imshow('frame', frame)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    color_object_detector = ColorObjectDetector()
    rclpy.spin(color_object_detector)
    color_object_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()