import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import time

# Define global variables for image width and height
widthImg = 640
heightImg = 480

# Function to preprocess the image for prediction
def preprocess_image(image):
    if image is None:
        return None

    if len(image.shape) > 2:
        grayscale_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        grayscale_img = image

    _, thresholded_img = cv2.threshold(grayscale_img, 128, 255, cv2.THRESH_BINARY)
    if np.sum(thresholded_img) < thresholded_img.shape[0] * thresholded_img.shape[1] * 255 * 0.9:
        return None  # Return None if no digit found

    inverted_img = 255 - thresholded_img  # Invert the colors
    kernel = np.ones((10, 10), np.uint8)  # Define the kernel for dilation
    dilated_img = cv2.dilate(inverted_img, kernel, iterations=2)  # Apply dilation

    resized = cv2.resize(dilated_img, (28, 28))
    resized = resized.astype("float") / 255.0
    resized = np.expand_dims(resized, axis=-1)
    resized = np.expand_dims(resized, axis=0)

    return resized

# Function to predict digit and confidence from image
def predict_digit_with_confidence(image):
    preprocessed_img = preprocess_image(image)
    if preprocessed_img is None:
        return None, 0  # No digit found
    prediction = model.predict(preprocessed_img)
    confidence = np.max(prediction)
    digit = np.argmax(prediction)
    return digit, confidence

# Function to reorder points of a quadrilateral
def reorder(myPoints):
    myPoints = myPoints.reshape((4, 2))
    myPointsNew = np.zeros((4, 1, 2), dtype=np.int32)
    add = myPoints.sum(1)

    myPointsNew[0] = myPoints[np.argmin(add)]
    myPointsNew[3] = myPoints[np.argmax(add)]
    diff = np.diff(myPoints, axis=1)
    myPointsNew[1] = myPoints[np.argmin(diff)]
    myPointsNew[2] = myPoints[np.argmax(diff)]

    return myPointsNew

# Function to find the biggest contour
def biggestContour(contours):
    biggest = np.array([])
    max_area = 0
    for i in contours:
        area = cv2.contourArea(i)
        if area > 5000:
            peri = cv2.arcLength(i, True)
            approx = cv2.approxPolyDP(i, 0.02 * peri, True)
            if area > max_area and len(approx) == 4:
                biggest = approx
                max_area = area
    return biggest, max_area

# Function to draw a rectangle
def drawRectangle(img, biggest, thickness):
    cv2.line(img, (biggest[0][0][0], biggest[0][0][1]), (biggest[1][0][0], biggest[1][0][1]), (0, 255, 0), thickness)
    cv2.line(img, (biggest[0][0][0], biggest[0][0][1]), (biggest[2][0][0], biggest[2][0][1]), (0, 255, 0), thickness)
    cv2.line(img, (biggest[3][0][0], biggest[3][0][1]), (biggest[2][0][0], biggest[2][0][1]), (0, 255, 0), thickness)
    cv2.line(img, (biggest[3][0][0], biggest[3][0][1]), (biggest[1][0][0], biggest[1][0][1]), (0, 255, 0), thickness)

    return img

class ImageSub(Node):

    def __init__(self):
        super().__init__('subscriber')

        self.subscriber = self.create_subscription(Image, '/oak/rgb/image_raw', self.listener_callback, 1)
        self.publisher_contours = self.create_publisher(Image, 'image_contours', 10)
        self.publisher_predicted = self.create_publisher(Image, 'PredictedDigitImage', 10)
        self.br = CvBridge()

        model_path = '/workspaces/ros_workspace/src/group4/group4/digit_recognition_model1 2.h5'
        # Load the pre-trained digit recognition model
        self.model = load_model(model_path)
        self        .model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

        # Declare and get ROS parameters for thresholds
        self.declare_parameter('threshold1', 200)
        self.declare_parameter('threshold2', 200)
        self.threshold1 = self.get_parameter('threshold1').value
        self.threshold2 = self.get_parameter('threshold2').value

        # Initialize timer and state variables
        self.last_prediction_time = 0
        self.prediction_interval = 5  # in seconds

    def preprocess_image(self, image):
        if image is None:
            return None

        if len(image.shape) > 2:
            grayscale_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            grayscale_img = image

        _, thresholded_img = cv2.threshold(grayscale_img, 128, 255, cv2.THRESH_BINARY)
        if np.sum(thresholded_img) < thresholded_img.shape[0] * thresholded_img.shape[1] * 255 * 0.9:
            return None  # Return None if no digit found

        inverted_img = 255 - thresholded_img  # Invert the colors
        kernel = np.ones((10, 10), np.uint8)  # Define the kernel for dilation
        dilated_img = cv2.dilate(inverted_img, kernel, iterations=2)  # Apply dilation

        resized = cv2.resize(dilated_img, (28, 28))
        resized = resized.astype("float") / 255.0
        resized = np.expand_dims(resized, axis=-1)
        resized = np.expand_dims(resized, axis=0)

        return resized

    def predict_digit_with_confidence(self, image):
        preprocessed_img = self.preprocess_image(image)
        if preprocessed_img is None:
            return None, 0  # No digit found
        prediction = self.model.predict(preprocessed_img)
        confidence = np.max(prediction)
        digit = np.argmax(prediction)
        return digit, confidence

    def listener_callback(self, msg):
        current_time = time.time()

        # Check if the node should be active
        if current_time - self.last_prediction_time < self.prediction_interval:
            return  # Skip processing if within the cooldown period

        current_frame = self.br.imgmsg_to_cv2(msg)

        # Paper Detection
        img = cv2.resize(current_frame, (widthImg, heightImg))
        imgBlank = np.zeros((heightImg, widthImg, 3), np.uint8)
        imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        imgBlur = cv2.GaussianBlur(imgGray, (5, 5), 1)
        imgThreshold = cv2.Canny(imgBlur, self.threshold1, self.threshold2)
        kernel = np.ones((1, 1))
        imgDial = cv2.dilate(imgThreshold, kernel, iterations=2)
        imgThreshold = cv2.erode(imgDial, kernel, iterations=1)

        imgContours = img.copy()
        imgBigContour = img.copy()
        contours, hierarchy = cv2.findContours(imgThreshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(imgContours, contours, -1, (0, 255, 0), 10)

        biggest, maxArea = biggestContour(contours)
        if biggest.size != 0:
            biggest = reorder(biggest)
            cv2.drawContours(imgBigContour, biggest, -1, (0, 255, 0), 20)
            imgBigContour = drawRectangle(imgBigContour, biggest, 2)
            pts1 = np.float32(biggest)
            pts2 = np.float32([[0, 0], [widthImg, 0], [0, heightImg], [widthImg, heightImg]])
            matrix = cv2.getPerspectiveTransform(pts1, pts2)
            imgWarpColored = cv2.warpPerspective(img, matrix, (widthImg, heightImg))

            imgWarpGray = cv2.cvtColor(imgWarpColored, cv2.COLOR_BGR2GRAY)
            imgAdaptiveThre = cv2.adaptiveThreshold(imgWarpGray, 255, 1, 1, 7, 2)
            imgAdaptiveThre = cv2.bitwise_not(imgAdaptiveThre)
            imgAdaptiveThre = cv2.medianBlur(imgAdaptiveThre, 3)

            digit, confidence = self.predict_digit_with_confidence(imgWarpGray)
            if digit is not None and confidence > 0.8:  # Check confidence threshold
                cv2.putText(imgBigContour, f"Digit: {digit}, Conf: {confidence:.2f}", (50, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                self.get_logger().info(f"Predicted Digit: {digit}, Confidence: {confidence:.2f}")
                imgCropped = imgWarpColored  # Crop the image to only show the paper
                imgCroppedMsg = self.br.cv2_to_imgmsg(imgCropped, encoding="bgr8")
                self.publisher_predicted.publish(imgCroppedMsg)
                self.last_prediction_time = current_time  # Update the last prediction time
            else:
                cv2.putText(imgBigContour, "No digit detected", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
        else:
            cv2.putText(imgBigContour, "No paper detected", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

        imgContoursMsg = self.br.cv2_to_imgmsg(imgBigContour, encoding="bgr8")
        self.publisher_contours.publish(imgContoursMsg)

def main(args=None):
    rclpy.init(args=args)
    image_sub = ImageSub()
    rclpy.spin(image_sub)
    image_sub.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

