import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Imu

class ImuCorrectionNode(Node):

    def __init__(self):
        super().__init__('imu_correction_node')
        self.subscription_imu = self.create_subscription(
            Imu,
            '/imu/data_raw',
            self.imu_callback,
            10)
        self.publisher_imu = self.create_publisher(Imu, '/imu/correction', 10)
        self.subscription_cmd_vel = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10)
        self.cmd_vel_received = False

def imu_callback(self, msg):
    if self.cmd_vel_received:
        if all(abs(val) > 0.05 for val in msg.linear_acceleration):
            corrected_msg = Imu()
            corrected_msg.header = msg.header
            corrected_msg.orientation = msg.orientation
            corrected_msg.angular_velocity = msg.angular_velocity
            corrected_msg.linear_acceleration = msg.linear_acceleration
            corrected_msg.angular_velocity.z = msg.angular_velocity.z * -1.0
            self.publisher_imu.publish(corrected_msg)



def cmd_vel_callback(self, msg):
    if msg.linear.x != 0.0 or msg.linear.y != 0.0 or msg.angular.z != 0.0:
        self.cmd_vel_received = True
    else:
        self.cmd_vel_received = False

def main(args=None):
    rclpy.init(args=args)
    imu_correction_node = ImuCorrectionNode()
    rclpy.spin(imu_correction_node)
    imu_correction_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
