import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import Joy
import math

class NavigationNode(Node):
    def __init__(self):
        super().__init__('navigation_node')
        self.subscription = self.create_subscription(
            Joy,
            'joy_topic',  # Replace with the actual joystick topic
            self.joy_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.publisher = self.create_publisher(PoseStamped, 'goal_pose', 10)
        self.home_x = 0.0
        self.home_y = 0.0
        self.is_navigating = False
        self.distance_threshold = 0.1  # Adjust this threshold as per your need

    def joy_callback(self, msg):
        if msg.buttons[2] == 1:  # Assuming the triangle button index is 2
            self.navigate_home()

    def navigate_home(self):
        goal_pose_msg = PoseStamped()
        goal_pose_msg.header.frame_id = "map"
        goal_pose_msg.pose.position.x = self.home_x
        goal_pose_msg.pose.position.y = self.home_y
        goal_pose_msg.pose.orientation.w = 1.0
        self.publisher.publish(goal_pose_msg)
        self.get_logger().info('Navigating to home position')

def main(args=None):
    rclpy.init(args=args)
    navigation_node = NavigationNode()
    rclpy.spin(navigation_node)
    navigation_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
