#!/usr/bin/bash

distro=humble

source /opt/ros/humble/setup.bash

colcon build

source install/setup.bash

ros2 launch group4 cam.launch.py
