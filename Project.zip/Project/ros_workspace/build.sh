#!/usr/bin/bash

distro=humble

colcon build
source ./install/setup.bash
